/*char* chauffage_state = "OFF";
const char* on = "ON";
const char* off = "OFF";
float chauffage_consumption = 0;
float chauffage_on_Consumption = 2000;
float chauffage_off_Consumption = 0;*/