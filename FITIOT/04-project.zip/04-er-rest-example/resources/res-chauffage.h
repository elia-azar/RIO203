extern char* chauffage_state;
extern float chauffage_consumption;
extern float chauffage_on_Consumption;
extern float chauffage_off_Consumption;