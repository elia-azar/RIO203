extern int light_info;
extern int pressure_info;
extern int last_light;
extern int last_pressure;
