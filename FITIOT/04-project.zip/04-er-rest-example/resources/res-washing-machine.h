extern char* washing_machine_state;
extern float washing_consumption;
extern float washing_on_Consumption;
extern float washing_off_Consumption;
float get_washing_machine();
char * get_washing_machine_state();
float get_washing_machine_consumption();
void change_washing_machine_state(int new_state);