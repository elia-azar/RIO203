extern int lamp_state;
extern float consumption;
extern float on_Consumption = 50;